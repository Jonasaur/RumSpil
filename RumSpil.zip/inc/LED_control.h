#include "stm32f30x_conf.h"
#include <stdio.h>
#include <string.h>

#ifndef _LED_CONTROL_H_
#define _LED_CONTROL_H_

void LED_setup();
int setLED (int in);

#endif

